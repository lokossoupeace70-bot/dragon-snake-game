# 🐉 Dragon Snake Game

Un jeu de Snake revisité avec une ambiance immersive, des graphismes inspirés d'un dragon/armure sombre, des effets sonores dynamiques, un système de vies et une bascule en mode sombre/clair.

---

## 🎮 Aperçu du Jeu
Ce projet est une version moderne et ludique du classique jeu du serpent, développé en **HTML5 Canvas**, **CSS3** et **JavaScript pur (Vanilla JS)**. Le serpent prend l'apparence d'un dragon ténébreux avec des yeux perçants, et le jeu intègre un système complet de vies, de scores, d'effets sonores et de musiques d'ambiance.

---

## ✨ Fonctionnalités Principales

- **Design Immersif (Style Dragon) :** Tête de dragon stylisée, yeux jaunes lumineux, corps blindé et anneaux dorés.
- **Écran de Game Over Rétro :** Design glitch/arcade inspiré des jeux d'époque lors de la perte de toutes les vies.
- **Système de Vies & Scores :** 3 cœurs de vie, suivi du score actuel et du meilleur score (*High Score*).
- **Mode Sombre / Mode Clair :** Bouton de bascule rapide pour changer l'ambiance visuelle du jeu selon vos préférences.
- **Audio & Musiques :** 
  - Effets sonores intégrés (bips/synthétiseurs Web Audio API) pour manger et mourir.
  - Possibilité de charger vos propres fichiers MP3 pour l'intro et la musique en jeu.
- **Commandes Flexibles :** Jouable au clavier (flèches directionnelles, ZQSD) ou via des boutons tactiles intégrés pour mobiles.

---

## 🛠️ Technologies Utilisées

- **HTML5** (Structure et Canvas)
- **CSS3** (Design moderne, animations et thèmes clair/sombre)
- **JavaScript (ES6+)** (Logique du jeu, gestion des collisions et Web Audio API)

---

## 🚀 Installation & Utilisation Locale

Aucune installation de dépendance n'est nécessaire ! Vous pouvez y jouer directement dans votre navigateur :

1. Décompressez l'archive ZIP.
2. Double-cliquez sur le fichier `index.html` pour l'ouvrir dans votre navigateur web (Chrome, Firefox, Edge, etc.).

---

## 👨‍💻 Auteur

Développé par **Kcanel Peace Lokossou** (Étudiant en informatique / Développeur).
